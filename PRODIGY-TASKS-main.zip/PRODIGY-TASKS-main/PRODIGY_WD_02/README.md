# Project README

This project was given by [Prodigy Infotech](https://prodigyinfotech.dev/) as Task 2.

See [Demo](https://hourglass.tilak-thapa.com.np/)

The title is "Hour Glass" and it is a timer app made with Vite.js, React, TypeScript, and Tailwind CSS. It functions as a stopwatch and can also measure laps.
